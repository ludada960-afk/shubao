// 薯包AI 商品提取器 — Popup 逻辑
(function () {
  const API_URL = 'http://localhost:3099/api/bookmarklet-extract';
  const APP_URL  = 'http://localhost:5173';

  const appEl = document.getElementById('app');

  function showLoading() {
    appEl.innerHTML = `<div class="empty"><div class="icon">⏳</div><p>分析页面数据...</p></div>`;
  }

  function showResult(data) {
    const hasData = data.title || data.images.length > 0;
    if (!hasData) {
      appEl.innerHTML = `
        <div class="body">
          <div class="status-bar err">⚠️ 未识别到商品信息</div>
          <p style="padding:8px 16px 0;font-size:11px;color:#888;line-height:1.6">
            当前页面可能没有标准商品数据。<br>
            · 确认在商品详情页（不是在列表页）
          </p>
          <div class="body" style="padding-top:6px">
            <div class="actions">
              <button class="btn btn-outline" onclick="window.close()">关闭</button>
            </div>
          </div>
        </div>`;
      return;
    }

    appEl.innerHTML = `
      <div class="body">
        <div class="status-bar ok">✅ 已识别商品信息</div>
        ${data.title ? `<div class="product-title">${escapeHtml(data.title)}</div>` : ''}
        ${data.brand ? `<div class="meta-row"><span>🏷️ ${escapeHtml(data.brand)}</span></div>` : ''}
        ${data.images.length ? `<div style="font-size:11px;color:#888;margin-bottom:6px">提取到 ${data.images.length} 张商品图</div><div class="img-grid">${data.images.map((u, i) => `<div class="img-item"><span class="img-index">#${i+1}</span><img src="${u}" onerror="this.parentElement.style.display='none'"><span class="img-dim">${u.split('.').pop().slice(0,3)}</span></div>`).join('')}</div>` : '<div class="no-images">⚠️ 未提取到商品图</div>'}
        ${data.sellingPoints.length ? `<div class="tag-wrap">${data.sellingPoints.map(s => `<span class="tag">${escapeHtml(s)}</span>`).join('')}</div>` : ''}
        <div class="actions">
          <button class="btn btn-primary" id="sendBtn">📦 发送到薯包AI</button>
          <button class="btn btn-outline" onclick="window.close()">取消</button>
        </div>
      </div>
      <div class="footer">确认图片后点击发送 · 数据不会保存</div>`;

    document.getElementById('sendBtn').addEventListener('click', async () => {
      document.getElementById('sendBtn').disabled = true;
      document.getElementById('sendBtn').textContent = '发送中...';
      try {
        const res = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: data.title || '',
            desc: data.description || '',
            brand: data.brand || '',
            images: data.images.slice(0, 8),
            sellingPoints: data.sellingPoints || [],
          }),
        });
        const result = await res.json();
        if (result.token) {
          window.open(APP_URL + '/?extract_token=' + result.token, '_blank');
          window.close();
        } else {
          alert('发送失败，请重试');
          document.getElementById('sendBtn').disabled = false;
          document.getElementById('sendBtn').textContent = '📦 发送到薯包AI';
        }
      } catch (e) {
        alert('发送失败：' + e.message);
        document.getElementById('sendBtn').disabled = false;
        document.getElementById('sendBtn').textContent = '📦 发送到薯包AI';
      }
    });
  }

  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  // ── 主流程 ──
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) {
      appEl.innerHTML = `<div class="empty"><div class="icon">❌</div><p>无法获取当前页面</p></div>`;
      return;
    }

    const supported = /taobao|tmall|jd\.com|pinduoduo|1688|amazon|amzn/.test(tab.url || '');
    if (!supported) {
      appEl.innerHTML = `
        <div class="body">
          <div class="status-bar err">⚠️ 请在商品页面使用</div>
          <div style="text-align:center;padding:10px 0;color:#888;font-size:12px">
            当前页面：${escapeHtml(tab.url || '').slice(0, 50)}<br>
            支持：淘宝 / 天猫 / 京东 / 拼多多 / 1688
          </div>
          <div class="actions">
            <button class="btn btn-outline" onclick="window.close()">关闭</button>
          </div>
        </div>`;
      return;
    }

    showLoading();

    // 主提取：用 world:MAIN 同时读取 JS 变量 + DOM（最全面）
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: () => {
        var data = { title: '', description: '', images: [], brand: '', sellingPoints: [] };

        // ═══ 1. 页面 JS 变量 ═══
        try {
          // 淘宝 g_config
          if (typeof g_config !== 'undefined' && g_config) {
            data.title = g_config.title || g_config.itemName || '';
            data.brand = (g_config.brand && g_config.brand.name) || g_config.brandName || '';
            var imgs = g_config.images || g_config.imageList || g_config.itemImages || [];
            if (Array.isArray(imgs)) imgs.forEach(function(u) { if (u && typeof u === 'string') data.images.push(u); });
          }
          // 淘宝 __INITIAL_STATE__
          if (typeof __INITIAL_STATE__ !== 'undefined' && __INITIAL_STATE__) {
            var s = __INITIAL_STATE__;
            var dt = s.detail || s.itemDetail || s.mainInfo || {};
            data.title = data.title || dt.title || dt.name || dt.itemName || '';
            data.brand = data.brand || (dt.brand && dt.brand.name) || '';
            var imgs = dt.images || dt.imageList || dt.pics || [];
            if (Array.isArray(imgs)) imgs.forEach(function(img) {
              var u = typeof img === 'string' ? img : (img.url || img.src || '');
              if (u && !/logo|icon|banner/i.test(u)) data.images.push(u);
            });
            // 淘宝详情模板数据
            if (dt.item && dt.item.images) {
              if (Array.isArray(dt.item.images)) dt.item.images.forEach(function(u) { if (u) data.images.push(u); });
            }
          }
          // 京东 pageConfig
          if (typeof pageConfig !== 'undefined' && pageConfig) {
            data.title = data.title || pageConfig.productName || pageConfig.name || '';
            data.brand = data.brand || pageConfig.brand || '';
            var imgs = pageConfig.imageList || pageConfig.images || [];
            if (Array.isArray(imgs)) imgs.forEach(function(img) {
              var u = typeof img === 'string' ? img : (img.url || img.src || '');
              if (u) data.images.push(u);
            });
          }
          // 拼多多
          if (typeof __rawData__ !== 'undefined' && __rawData__) {
            data.title = data.title || __rawData__.goodsName || __rawData__.name || '';
            if (__rawData__.thumbUrl) data.images.push(__rawData__.thumbUrl);
            if (__rawData__.hdThumbUrl) data.images.push(__rawData__.hdThumbUrl);
          }
        } catch(e) {}

        // ═══ 2. JSON-LD ═══
        if (!data.title || !data.images.length) {
          try {
            document.querySelectorAll('script[type="application/ld+json"]').forEach(function(s) {
              try {
                var p = JSON.parse(s.textContent);
                (p['@graph'] || [p]).forEach(function(item) {
                  if (item['@type'] === 'Product') {
                    data.title = data.title || item.name || '';
                    data.description = data.description || item.description || '';
                    data.brand = data.brand || (item.brand && item.brand.name) || '';
                    if (!data.images.length) {
                      var imgs = item.image || [];
                      (Array.isArray(imgs) ? imgs : [imgs]).forEach(function(img) {
                        var u = typeof img === 'string' ? img : (img.url || '');
                        if (u && !/logo|icon|banner/i.test(u)) data.images.push(u);
                      });
                    }
                  }
                });
              } catch(e) {}
            });
          } catch(e) {}
        }

        // ═══ 3. OG 标签 ═══
        if (!data.title) {
          var t = document.querySelector('meta[property="og:title"], meta[name="title"]');
          if (t) data.title = t.getAttribute('content') || '';
        }
        if (!data.images.length) {
          var oi = document.querySelector('meta[property="og:image"]');
          if (oi) data.images.push(oi.getAttribute('content') || '');
        }

        // ═══ 4. 页面标题降级 ═══
        if (!data.title) {
          data.title = document.title
            .replace(/[_-].*$|（.*$|\(.*$| 淘宝| 京东| 拼多多| TMALL| JD\.COM| 天猫/i, '')
            .trim() || '';
        }

        // ═══ 5. 暴力捞图片：页面里所有商品图 ═══
        try {
          var pageImgs = document.querySelectorAll('img');
          var bestImages = [];
            var minSize = 50;  // 降低阈值，SKU小图也能捞到
            pageImgs.forEach(function(img) {
              var w = img.naturalWidth || img.width || 0;
              var h = img.naturalHeight || img.height || 0;
              var src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-original') || '';
              // 排除小图标，捞商品图
              if (w >= minSize && h >= minSize && src &&
                  !/logo|icon|banner|avatar|sprite|favicon|emoji|search|cart|user/i.test(src) &&
                  !/\.svg/.test(src)) {
                bestImages.push({ src: src, area: w * h });
              }
            });
            // 按面积排序
            bestImages.sort(function(a, b) { return b.area - a.area; });
            bestImages.slice(0, 20).forEach(function(img) {
              var u = img.src;
              if (u.startsWith('//')) u = 'https:' + u;
              if (u.startsWith('/') && !u.startsWith('//')) u = window.location.origin + u;
              data.images.push(u);
            });
          } catch(e) {}

        // ═══ 6. 卖点 ═══
        try {
          var sellers = document.querySelectorAll(
            '.selling-point, .feature-list li, [class*="attribute"] li, ' +
            '[class*="sell"] li, [class*="feature"] li, [class*="point"] li, ' +
            '#attributes li, .attributes-list li, .params li, .J_AttrRow, .SKU li'
          );
          data.sellingPoints = Array.from(sellers).map(function(el) { return el.textContent.trim(); })
            .filter(function(t) { return t.length > 2 && t.length < 50; }).slice(0, 5);
        } catch(e) {}

        // 去重 + 过滤LOGO
        data.images = [...new Set(data.images)]
          .filter(function(u) { return u && !/logo|icon|banner|sprite|favicon/i.test(u); });
        // 不设上限，展示全部

        data.title = data.title || '';
        return data;
      },
    }, (results) => {
      if (results && results[0] && results[0].result) {
        var d = results[0].result;
        if (d.title || (d.images && d.images.length)) {
          showResult(d);
          return;
        }
      }
      // 最终降级
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          var data = { title: '', images: [] };
          var t = document.querySelector('meta[property="og:title"]');
          if (t) data.title = t.getAttribute('content') || '';
          if (!data.title) data.title = document.title.replace(/[_-].*$|（.*$|\(.*$| 淘宝| 京东/i, '').trim() || '';
          var i = document.querySelector('meta[property="og:image"]');
          if (i) data.images.push(i.getAttribute('content') || '');
          return data;
        },
      }, (res2) => {
        if (res2 && res2[0] && res2[0].result) showResult(res2[0].result);
        else showResult({ title: '', images: [] });
      });
    });
  });
})();
