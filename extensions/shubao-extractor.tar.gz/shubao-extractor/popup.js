// 薯包AI 商品提取器 — Popup 逻辑
(function () {
  const API_URL = 'http://localhost:3099/api/bookmarklet-extract';
  const APP_URL  = 'http://localhost:5173';

  const appEl = document.getElementById('app');

  function showLoading() {
    appEl.innerHTML = `<div class="empty"><div class="icon">⏳</div><p>分析页面数据...</p></div>`;
  }

  function showResult(data) {
    const hasData = data.title || data.images.length > 0;
    if (!hasData) {
      appEl.innerHTML = `
        <div class="body">
          <div class="status-bar err">⚠️ 未识别到商品信息，请确认是否在商品页面</div>
          <div class="actions">
            <button class="btn btn-outline" onclick="window.close()">关闭</button>
          </div>
        </div>`;
      return;
    }

    appEl.innerHTML = `
      <div class="body">
        <div class="status-bar ok">✅ 已识别商品信息</div>
        ${data.title ? `<div class="field"><div class="field-label">商品名称</div><div class="field-value">${escapeHtml(data.title)}</div></div>` : ''}
        ${data.brand ? `<div class="field"><div class="field-label">品牌</div><div class="field-value">${escapeHtml(data.brand)}</div></div>` : ''}
        ${data.images.length ? `<div class="field"><div class="field-label">商品图</div><div class="field-value img-list">${data.images.slice(0, 3).map(u => `<img src="${u}" onerror="this.style.display='none'">`).join('')}</div></div>` : ''}
        ${data.sellingPoints.length ? `<div class="field"><div class="field-label">卖点</div><div class="field-value">${data.sellingPoints.map(s => `<span class="tag">${escapeHtml(s)}</span>`).join('')}</div></div>` : ''}
        <div class="actions">
          <button class="btn btn-primary" id="sendBtn">📦 发送到薯包AI</button>
          <button class="btn btn-outline" onclick="window.close()">取消</button>
        </div>
      </div>
      <div class="footer">数据仅用于生成商品图，不会保存</div>`;

    document.getElementById('sendBtn').addEventListener('click', async () => {
      document.getElementById('sendBtn').disabled = true;
      document.getElementById('sendBtn').textContent = '发送中...';
      try {
        const res = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: data.title || '',
            desc: data.description || '',
            brand: data.brand || '',
            images: data.images.slice(0, 5),
            sellingPoints: data.sellingPoints || [],
          }),
        });
        const result = await res.json();
        if (result.token) {
          window.open(APP_URL + '/?extract_token=' + result.token, '_blank');
          window.close();
        } else {
          alert('发送失败，请重试');
          document.getElementById('sendBtn').disabled = false;
          document.getElementById('sendBtn').textContent = '📦 发送到薯包AI';
        }
      } catch (e) {
        alert('发送失败：' + e.message);
        document.getElementById('sendBtn').disabled = false;
        document.getElementById('sendBtn').textContent = '📦 发送到薯包AI';
      }
    });
  }

  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  // 读取 content script 提取的数据
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) {
      appEl.innerHTML = `<div class="empty"><div class="icon">❌</div><p>无法获取当前页面</p></div>`;
      return;
    }
    // 检查是否在支持的网站上
    const supported = /taobao|tmall|jd\.com|pinduoduo|1688/.test(tab.url || '');
    if (!supported) {
      appEl.innerHTML = `
        <div class="body">
          <div class="status-bar err">⚠️ 请在商品页面使用</div>
          <div style="text-align:center;padding:10px 0;color:#888;font-size:12px">
            当前页面：${escapeHtml(tab.url || '').slice(0, 50)}<br>
            支持的网站：淘宝 / 天猫 / 京东 / 拼多多 / 1688
          </div>
          <div class="actions">
            <button class="btn btn-outline" onclick="window.close()">关闭</button>
          </div>
        </div>`;
      return;
    }

    showLoading();

    // 先尝试直接读 content script 的挂载数据
    chrome.tabs.sendMessage(tab.id, { action: 'getProductData' }, (response) => {
      if (response && (response.title || (response.images && response.images.length))) {
        showResult(response);
      } else {
        // Content script 还没加载？注入脚本执行一次
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const scripts = document.querySelectorAll('script[type="application/ld+json"]');
            const data = { title: '', description: '', images: [], brand: '', sellingPoints: [] };
            for (const s of scripts) {
              try {
                const parsed = JSON.parse(s.textContent);
                const items = parsed['@graph'] || [parsed];
                for (const item of items) {
                  if (item['@type'] === 'Product') {
                    data.title = data.title || item.name || '';
                    data.description = data.description || item.description || '';
                    data.brand = data.brand || (item.brand && item.brand.name) || '';
                    const imgs = item.image || [];
                    (Array.isArray(imgs) ? imgs : [imgs]).forEach(img => {
                      const url = typeof img === 'string' ? img : (img.url || '');
                      if (url && !/logo|icon|banner|avatar|sprite/i.test(url)) data.images.push(url);
                    });
                    break;
                  }
                }
              } catch (e) { /* skip */ }
            }
            if (!data.title) {
              const ot = document.querySelector('meta[property="og:title"]');
              if (ot) data.title = ot.getAttribute('content') || '';
            }
            if (!data.images.length) {
              const oi = document.querySelector('meta[property="og:image"]');
              if (oi) data.images.push(oi.getAttribute('content') || '');
            }
            data.images = [...new Set(data.images)].slice(0, 5);
            return data;
          },
        }, (results) => {
          if (results && results[0] && results[0].result) {
            showResult(results[0].result);
          } else {
            appEl.innerHTML = `
              <div class="body">
                <div class="status-bar err">⚠️ 未识别到商品信息</div>
                <div class="actions">
                  <button class="btn btn-outline" onclick="window.close()">关闭</button>
                </div>
              </div>`;
          }
        });
      }
    });
  });
})();
