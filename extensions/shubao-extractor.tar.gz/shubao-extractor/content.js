// 薯包AI 商品提取器 — 内容脚本
// 在商品页面运行时，提取 JSON-LD 结构化数据，供 popup 使用

(function () {
  // 避免重复注入
  if (window.__SHUBAO_EXTRACTOR_LOADED) return;
  window.__SHUBAO_EXTRACTOR_LOADED = true;

  function extractProductData() {
    const data = { title: '', description: '', images: [], brand: '', sellingPoints: [] };

    try {
      // 1. JSON-LD 提取（最准确）
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const s of scripts) {
        try {
          const parsed = JSON.parse(s.textContent);
          const items = parsed['@graph'] || [parsed];
          for (const item of items) {
            if (item['@type'] === 'Product' || item['@type'] === 'ItemPage') {
              data.title = data.title || item.name || '';
              data.description = data.description || item.description || '';
              data.brand = data.brand || (item.brand && item.brand.name) || '';
              const imgs = item.image || [];
              const imgList = Array.isArray(imgs) ? imgs : [imgs];
              imgList.forEach(img => {
                const url = typeof img === 'string' ? img : (img.url || '');
                if (url && !/logo|icon|banner|avatar|sprite/i.test(url)) {
                  data.images.push(url);
                }
              });
              break;
            }
          }
        } catch (e) { /* skip invalid JSON-LD */ }
      }

      // 2. OG 标签补充
      if (!data.title) {
        const ogTitle = document.querySelector('meta[property="og:title"]');
        if (ogTitle) data.title = ogTitle.getAttribute('content') || '';
      }
      if (data.images.length === 0) {
        const ogImg = document.querySelector('meta[property="og:image"]');
        if (ogImg) data.images.push(ogImg.getAttribute('content') || '');
      }

      // 3. 尝试提取卖点
      try {
        const sellers = document.querySelectorAll(
          '.selling-point, .feature-list li, .desc-wrap .attributes span, ' +
          '[class*="sell"] li, [class*="feature"] li, [class*="point"] li'
        );
        data.sellingPoints = Array.from(sellers)
          .map(el => el.textContent.trim())
          .filter(t => t.length > 2 && t.length < 50)
          .slice(0, 5);
      } catch (e) { /* skip */ }

      // 去重图片
      data.images = [...new Set(data.images)].slice(0, 5);
    } catch (e) {
      console.warn('[薯包AI] 提取失败:', e);
    }

    return data;
  }

  // 把提取结果挂到 window 上，popup 可以直接读
  window.__SHUBAO_PRODUCT_DATA = extractProductData();
})();
