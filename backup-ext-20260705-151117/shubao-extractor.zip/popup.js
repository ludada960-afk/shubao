// 薯包AI 商品提取器 — Popup 逻辑
(function () {
  const API_URL = 'http://localhost:3099/api/bookmarklet-extract';
  const APP_URL  = 'http://localhost:5173';

  const appEl = document.getElementById('app');

  function showLoading() {
    appEl.innerHTML = `<div class="empty"><div class="icon">⏳</div><p>分析页面数据...</p></div>`;
  }

  function catLabel(cat) {
    return { main: '商品主图', other: '其他图片' }[cat] || '图片';
  }

  function showResult(data) {
    const hasData = data.title || data.images.length > 0;
    if (!hasData) {
      appEl.innerHTML = `
        <div class="body">
          <div class="status-bar err">⚠️ 未找到商品图</div>
          <p style="padding:4px 0;font-size:11px;color:#888">试试刷新页面后再点插件</p>
          ${data.debug ? '<details style="margin-top:8px"><summary style="font-size:11px;color:#6366F1;cursor:pointer">调试信息</summary><pre style="font-size:10px;color:#666;background:#f5f5f5;padding:8px;border-radius:6px;max-height:300px;overflow:auto;white-space:pre-wrap;margin-top:6px">' + escapeHtml(data.debug) + '</pre></details>' : ''}
          <div class="actions" style="padding-top:8px">
            <button class="btn btn-outline" onclick="window.close()">关闭</button>
          </div>
        </div>`;
      return;
    }

    var groups = {};
    data.images.forEach(function(img) {
      var c = img.cat || 'other';
      if (!groups[c]) groups[c] = [];
      groups[c].push(img.url);
    });

    var totalByCat = '';
    for (var g in groups) {
      totalByCat += ' · ' + catLabel(g) + ' ' + groups[g].length + '张';
    }

    var html = '';
    for (var g in groups) {
      var imgs = groups[g];
      html += '<div style="display:flex;align-items:center;gap:6px;margin:0 0 4px">';
      html += '<span style="font-size:11px;font-weight:600;color:#555">' + catLabel(g) + '</span>';
      html += '<span style="font-size:10px;color:#999">' + imgs.length + '张</span>';
      html += '</div>';
      html += '<div class="img-grid">';
      imgs.forEach(function(u, i) {
        var fname = u.split('/').pop().split('?')[0].slice(0, 16);
        html += '<div class="img-item"><span class="img-index">#' + (i+1) + '</span>';
        html += '<img src="' + u + '" onerror="this.parentElement.style.display=\'none\'">';
        html += '<span class="img-dim">' + fname + '</span></div>';
      });
      html += '</div>';
    }

    var allUrls = data.images.map(function(i) { return i.url; });

    appEl.innerHTML = `
      <div class="body">
        <div class="status-bar ok">✅ 已识别</div>
        ${data.title ? `<div class="product-title">${escapeHtml(data.title)}</div>` : ''}
        ${data.brand ? `<div class="meta-row"><span>🏷️ ${escapeHtml(data.brand)}</span></div>` : ''}
        <div style="font-size:10px;color:#aaa;margin-bottom:8px">共 ${data.images.length} 张${totalByCat}</div>
        ${html}
        ${data.sellingPoints.length ? `<div style="margin-top:8px" class="tag-wrap">${data.sellingPoints.map(function(s){return '<span class="tag">'+escapeHtml(s)+'</span>'}).join('')}</div>` : ''}
        <div class="actions">
          <button class="btn btn-primary" id="sendBtn">📦 发送到薯包AI（发前 8 张）</button>
          <button class="btn btn-outline" onclick="window.close()">取消</button>
        </div>
      </div>
      <div class="footer">确认图片后点击发送</div>`;

    document.getElementById('sendBtn').addEventListener('click', async () => {
      document.getElementById('sendBtn').disabled = true;
      document.getElementById('sendBtn').textContent = '发送中...';
      try {
        var sendUrls = allUrls.filter(function(u) { return u; }).slice(0, 8);
        var res = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: data.title || '',
            desc: data.description || '',
            brand: data.brand || '',
            images: sendUrls,
            sellingPoints: data.sellingPoints || [],
          }),
        });
        var result = await res.json();
        if (result.token) {
          window.open(APP_URL + '/?extract_token=' + result.token, '_blank');
          window.close();
        } else {
          alert('发送失败，请重试');
          document.getElementById('sendBtn').disabled = false;
          document.getElementById('sendBtn').textContent = '📦 发送到薯包AI';
        }
      } catch (e) {
        alert('发送失败：' + e.message);
        document.getElementById('sendBtn').disabled = false;
        document.getElementById('sendBtn').textContent = '📦 发送到薯包AI';
      }
    });
  }

  function escapeHtml(s) {
    var d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  // ── 主流程 ──
  var LOADING_TIMEOUT = setTimeout(function() {
    appEl.innerHTML = '<div class="body"><div class="status-bar err">⏱️ 请求超时，请刷新页面重试</div><div class="actions"><button class="btn btn-outline" onclick="window.close()">关闭</button></div></div>';
  }, 15000);

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    var tab = tabs[0];
    if (!tab) {
      clearTimeout(LOADING_TIMEOUT);
      appEl.innerHTML = '<div class="empty"><div class="icon">❌</div><p>无法获取当前页面</p></div>';
      return;
    }

    var supported = /taobao|tmall|jd\.com|pinduoduo|1688/.test(tab.url || '');
    if (!supported) {
      clearTimeout(LOADING_TIMEOUT);
      appEl.innerHTML = '\
        <div class="body">\
          <div class="status-bar err">⚠️ 请在商品页面使用</div>\
          <div style="text-align:center;padding:10px 0;color:#888;font-size:12px">\
            当前页面：' + escapeHtml(tab.url || '').slice(0, 50) + '<br>\
            支持：淘宝 / 天猫 / 京东 / 拼多多 / 1688\
          </div>\
          <div class="actions">\
            <button class="btn btn-outline" onclick="window.close()">关闭</button>\
          </div>\
        </div>';
      return;
    }

    showLoading();

    function finish(data) {
      clearTimeout(LOADING_TIMEOUT);
      if (data && (data.title || (data.images && data.images.length) || data.debug)) {
        showResult(data);
      } else {
        showResult({ title: '', images: [], debug: '无法提取到数据' });
      }
    }

    // 主提取：注入 script 读页面变量 + DOM 提取
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        var result = { title: '', images: [], brand: '', debug: '' };
        var seen = {};
        var logs = [];

        function addUrl(u) {
          if (!u || typeof u !== 'string' || u.length < 20) return;
          if (u.startsWith('//')) u = 'https:' + u;
          if (!/\.(jpg|jpeg|png|webp)(\?|$)/i.test(u)) return;
          if (/\/(logo|icon|banner|avatar|favicon|sprite)\//i.test(u)) return;
          if (!seen[u]) seen[u] = true;
        }

        // ══ 注入 script 读页面 JS 变量 ══
        try {
          var inj = document.createElement('script');
          inj.textContent = '(' + function pageScript() {
            var d = document.documentElement;
            var out = { gKey: [], gTitle: '', initKey: [], initDetailKey: [], initTitle: '', imgField: {}, pcKey: [] };
            try {
              if (typeof g_config !== 'undefined') { out.gKey = Object.keys(g_config); if (g_config.title) out.gTitle = g_config.title; }
              if (typeof __INITIAL_STATE__ !== 'undefined') {
                var st = __INITIAL_STATE__;
                out.initKey = Object.keys(st);
                var dt = st.detail || st.itemDetail || st.mainInfo || {};
                out.initDetailKey = Object.keys(dt);
                if (dt.title) out.initTitle = dt.title;
                else if (dt.name) out.initTitle = dt.name;
                else if (dt.item && dt.item.title) out.initTitle = dt.item.title;
                // 收集所有图片字段
                ['images','pics','imageList','imageUrls','mainImages','gallery'].forEach(function(k) {
                  var v = dt[k];
                  if (Array.isArray(v)) out.imgField['detail.'+k] = v.map(function(x) { return typeof x === 'string' ? x : (x.url||x.src||''); }).filter(Boolean).slice(0,20);
                });
                if (dt.item) {
                  ['images','pics','imageList'].forEach(function(k) {
                    var v = dt.item[k];
                    if (Array.isArray(v)) out.imgField['item.'+k] = v.map(function(x) { return typeof x === 'string' ? x : (x.url||x.src||''); }).filter(Boolean).slice(0,20);
                  });
                }
              }
              if (typeof pageConfig !== 'undefined') { out.pcKey = Object.keys(pageConfig); }
            } catch(e) {}
            d.setAttribute('data-sb-out', JSON.stringify(out));
          } + ')()';
          document.documentElement.appendChild(inj);
          inj.remove();
        } catch(e) { logs.push('注入异常: ' + e.message); }

        // ══ 读取 JS 数据 ══
        try {
          var raw = document.documentElement.getAttribute('data-sb-out');
          if (raw) {
            var out = JSON.parse(raw);
            logs.push('g_config: ' + (out.gKey ? out.gKey.length + '个key' : 'undefined'));
            logs.push('__INITIAL_STATE__: ' + (out.initKey ? out.initKey.length + '个key' : 'undefined'));
            logs.push('detail keys: ' + (out.initDetailKey ? out.initDetailKey.join(', ').slice(0, 80) : 'N/A'));
            logs.push('pageConfig: ' + (out.pcKey ? out.pcKey.length + '个key' : 'undefined'));
            result.title = out.gTitle || out.initTitle || '';
            // 图片字段
            if (out.imgField) {
              for (var k in out.imgField) {
                if (Array.isArray(out.imgField[k]) && out.imgField[k].length) {
                  logs.push(k + ': ' + out.imgField[k].length + '张');
                  out.imgField[k].forEach(function(u) { addUrl(u); });
                }
              }
            }
          } else {
            logs.push('data-sb-out 为空');
          }
        } catch(e) { logs.push('读取出错: ' + e.message); }

        // ══ DOM 相册图 ══
        try {
          var gallerySelectors = [
            '#J_ImgBooth', '.tb-booth img', '#spec-img',
            '[class*="gallery"] img', '[class*="preview"] img',
            '#J_UlThr img', '.tb-thumb img', '.spec-items img',
          ];
          var total = 0;
          gallerySelectors.forEach(function(sel) {
            document.querySelectorAll(sel).forEach(function(el) {
              total++;
              var src = el.getAttribute('src') || el.getAttribute('data-src') || '';
              if (src) addUrl(src);
            });
          });
          logs.push('DOM相册: ' + total + '个元素');
        } catch(e) { logs.push('DOM: ' + e.message); }

        // ══ JSON-LD ══
        try {
          document.querySelectorAll('script[type="application/ld+json"]').forEach(function(s) {
            try {
              var p = JSON.parse(s.textContent);
              (p['@graph'] || [p]).forEach(function(item) {
                if (item['@type'] === 'Product') {
                  result.title = result.title || item.name || '';
                  var imgs = item.image || [];
                  (Array.isArray(imgs) ? imgs : [imgs]).forEach(function(i) { addUrl(typeof i === 'string' ? i : (i.url || '')); });
                }
              });
            } catch(e) {}
          });
        } catch(e) {}

        // ══ OG ══
        if (!result.title) {
          var ogt = document.querySelector('meta[property="og:title"]');
          if (ogt) result.title = ogt.getAttribute('content') || '';
        }
        if (Object.keys(seen).length < 3) {
          var oi = document.querySelector('meta[property="og:image"]');
          if (oi) addUrl(oi.getAttribute('content') || '');
        }

        if (!result.title) result.title = document.title.replace(/[_-].*$|（.*$|\(.*$| 淘宝| 京东| 拼多多| TMALL/i, '').trim() || '';

        result.images = Object.keys(seen).map(function(u) { return { url: u, cat: 'main' }; });
        result.debug = logs.join('\n');
        return result;
      },
    }, function(results) {
      if (results && results[0] && results[0].result) {
        finish(results[0].result);
      } else {
        finish({ title: '', images: [], debug: 'executeScript 无返回' });
      }
    });
  });
})();
